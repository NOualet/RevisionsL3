// Auteur : Mathieu G.
// Site : http://www.design-patterns.fr
// Licence : GNU General Public License
package decorateur;

// Classe abstraite decorateurIngredient qui hérite de dessert.
public abstract class DecorateurIngredient extends Dessert
{
	protected Dessert dessert;// Dessert sur leuquel on applique l'ingrédient.
	
	// On oblige les ingrédients à implémenter la méthode getLibelle().
	public abstract String getLibelle();
	// On oblige les ingrédients à implémenter la méthode getPrix().
	public abstract double getPrix();
}
