// Auteur : Mathieu G.
// Site : http://www.design-patterns.fr
// Licence : GNU General Public License
package decorateur;

// Classe crêpe qui hérite de dessert.
public class Crepe extends Dessert
{
	// Constructeur qui initialise le libellé et le prix.
	public Crepe()
	{
		setLibelle("Crêpe");
		setPrix(1.50);
	}
}
