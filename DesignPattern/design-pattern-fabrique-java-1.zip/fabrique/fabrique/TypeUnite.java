/**
 * Copyright : Mathieu G. - http://www.design-patterns.fr
 * Licence : GNU General Public License v3 ou ultérieure, voir http://www.gnu.org/licenses/
 */
package fabrique;

// Enumération des types d'unités.
public enum TypeUnite 
{
	SOLDAT,
	COMMANDANT
}
